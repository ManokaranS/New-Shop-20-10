package dbmanagment;

import org.springframework.stereotype.Controller;

@Controller
public class ProductBean {

	private String[] product;
	
	public String[] getProduct() {
		return product;
	}
	public void setProduct(String[] product) {
		this.product = product;
	}
	private String page;
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
}
